package simpleboard.common;

public class DatabaseException extends Exception {
    public DatabaseException(String message) {
        super(message);
    }
}
